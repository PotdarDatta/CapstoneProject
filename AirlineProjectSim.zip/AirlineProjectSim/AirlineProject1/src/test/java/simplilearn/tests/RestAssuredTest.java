package simplilearn.tests;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import static org.testng.Assert.assertTrue;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;
public class RestAssuredTest {
		@Test
		public void restassuredTest() {
			
			RestAssured.baseURI= "http://localhost:8080/FlyAway/";
			
			//given().log().all().queryParam("page", "2").header("Connection","keep-alive").when().get("/api/users?page=2").then().log().all().assertThat().statusCode(200).
			
				String getPlaceResponse=	given().log().all().queryParam("id", "8").header("Connection","keep-alive")
						
						.when().get("bookflight?id=8")
						.then().assertThat().log().all().statusCode(200).extract().response().asString();
				System.out.println(getPlaceResponse);
			
		}
		

}
