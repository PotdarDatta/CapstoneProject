package simplilearn.tests;

import org.testng.annotations.Test;

import simplilearn.pageObject.BookingPage;
import simplilearn.pageObject.PaymentGateway;
import simplilearn.pageObject.confirmPage;
import simplilearn.pageObject.signInPage;
import simplilearn.testsComponents.BaseTest;

public class AirlineTestSenario extends BaseTest {

	@Test
	public void loginValidation() {

		signInPage signInPage = LandingPage.AirSignupbutton();

		signInPage.AirCustomerDetails("amit@amit.com", "aaaaaa");
		signInPage.AirLogInButton();
		

	}
	
	
	
	
	
}
