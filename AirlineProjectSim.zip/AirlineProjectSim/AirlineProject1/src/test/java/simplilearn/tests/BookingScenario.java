package simplilearn.tests;

import org.testng.annotations.Test;

import simplilearn.pageObject.BookingPage;
import simplilearn.pageObject.PaymentGateway;
import simplilearn.pageObject.confirmPage;
import simplilearn.pageObject.signInPage;
import simplilearn.testsComponents.BaseTest;

public class BookingScenario extends BaseTest {
	
	@Test
	public void bookingScenario() {
		
		signInPage signInPage = LandingPage.AirSignupbutton();

		signInPage.AirCustomerDetails("amit@amit.com", "aaaaaa");
		BookingPage BookingPage = signInPage.AirLogInButton();
		BookingPage.homeButton();
		BookingPage.selectSource("Bangalore");
		BookingPage.selectDestination("Chennai");
		BookingPage.submitButton();
		PaymentGateway PaymentGateway = BookingPage.bookFlight();
		PaymentGateway.cardDetails("4597598873", "Datta", "12/27", "223");
		PaymentGateway.makepayment();
		confirmPage confirmPage = PaymentGateway.confirm();
		confirmPage.seeBooking();
		
	}

}
