package simplilearn.pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import simplilearn.AbstractComponents.AbstractComponents;

public class confirmPage extends AbstractComponents {

	public confirmPage(WebDriver driver) {
		super(driver);
		
		this.driver = driver;
		PageFactory.initElements(driver, this);
		
	}
	
	@FindBy(xpath = "//a[normalize-space()='See Your Bookings']")
WebElement seebookingElement;
	
	public void seeBooking() {
		
		waitForWebElementToClickable(seebookingElement);
		seebookingElement.click();
	}
	
	
}
