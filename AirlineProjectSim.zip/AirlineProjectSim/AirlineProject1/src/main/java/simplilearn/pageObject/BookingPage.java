package simplilearn.pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import simplilearn.AbstractComponents.AbstractComponents;

public class BookingPage extends AbstractComponents {

	public BookingPage(WebDriver driver) {
		super(driver);
		this.driver=driver;
		PageFactory.initElements(driver, this);
		
	}

	
	@FindBy(xpath = "//a[normalize-space()='Home']")
	WebElement homeButtonElement;
	@FindBy(xpath = "//select[@name='source']")
	WebElement sourcElement;
	
	@FindBy(xpath = "//select[@name='destination']")
 WebElement destinationElement;
	
	@FindBy(xpath = "//button[normalize-space()='Submit']")
	WebElement submitElement;
	
	@FindBy(xpath = "//tbody/tr[2]/td[6]/a[1]")
	WebElement bookFLightElement;
	
	public void homeButton() {
		waitForWebElementToClickable(homeButtonElement);
		homeButtonElement.click();
	}
	
	public void selectSource(String SourceName) {
		
		selectDropdawn(sourcElement, SourceName);
		
	}
	
	public void selectDestination(String DestinationName) {
		
		selectDropdawn(destinationElement, DestinationName);
	}
	
	public void submitButton() {
		
		submitElement.click();
	}
	
	public PaymentGateway bookFlight() {
		waitForWebElementToClickable(bookFLightElement);
		bookFLightElement.click();
		PaymentGateway PaymentGateway = new PaymentGateway(driver);
		return PaymentGateway;
	}
	
	
	
	
	
}
