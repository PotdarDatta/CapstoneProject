package simplilearn.pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import simplilearn.AbstractComponents.AbstractComponents;

public class PaymentGateway extends AbstractComponents{

	public PaymentGateway(WebDriver driver) {
		super(driver);
		this.driver= driver;
		PageFactory.initElements(driver, this);
	}
	
	
	@FindBy(xpath = "//input[@id='card-number']")
	WebElement cardNoElement;
	
	@FindBy(xpath = "//input[@id='card-name']")
  WebElement cardName;	
	
	@FindBy(xpath = "//input[@id='expiry']")
	WebElement expiryElement;
	
	@FindBy(xpath = "//input[@id='cvv']")
	WebElement cvvElement;
	
	@FindBy(xpath = "//button[@id='submit-btn']")
	WebElement makepaymentbutton;
	
	@FindBy(xpath = "//a[normalize-space()='Click to complete booking']")
	WebElement confirmElement;
	public void cardDetails(String cardnumber ,String cardname ,String date,String cvv) {
		waitForWebElementToAppear(cardName);
	
		cardNoElement.sendKeys(cardnumber);
		cardName.sendKeys(cardname);
		expiryElement.sendKeys(date);
		cvvElement.sendKeys(cvv);
		
	}
	public void makepayment() {
		makepaymentbutton.click();
		
	}
	public confirmPage confirm() {
		
		confirmElement.click();
		confirmPage confirmPage= new confirmPage(driver);
		return confirmPage;
	}
	
	
	
	

}
